export interface Button3Props {
  /**
   * Variant
   * Options: "KVtNyjkum" | "L2bOEAnUj" | "slGrJQ14R"
   */
  variant?: 'KVtNyjkum' | 'L2bOEAnUj' | 'slGrJQ14R';
  /**
   * Button Title
   * @default "Get A Free Quote"
   */
  t0cs1rgsC?: string;
  ont0cs1rgsCChange?: string;
  /**
   * Text Color
   * @default "var(--token-7c1746b7-c57b-4b3e-8391-742de5bfab8e, rgb(31, 31, 31))"
   */
  d5Z9jcCgg?: string;
  /**
   * Fill color
   * @default "var(--token-9e8a9b46-d051-431c-8150-32b11507662e, rgb(190, 221, 37)) /* {"name":"Color 01"} */"
   */
  wpuSwT88D?: string;
  /**
   * Link
   */
  GRp9o5uZg?: string;
  /** Additional properties */
  [key: string]: unknown;
}
