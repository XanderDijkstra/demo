export interface I1fnwp21f3Props {
  /**
   * Variant
   * Options: "rnvbXGwR4" | "GeHjIsukF" | "IT3JICTb5" | "NgxmXlQ6w" | "eXXZ6RU9t" | "uVU3ctcSy" | "XSQPKi8in" | "kAA8WhZYY" | "DhXPQp8TO" | "DYZ9a0_Yf"
   */
  variant?: 'rnvbXGwR4' | 'GeHjIsukF' | 'IT3JICTb5' | 'NgxmXlQ6w' | 'eXXZ6RU9t' | 'uVU3ctcSy' | 'XSQPKi8in' | 'kAA8WhZYY' | 'DhXPQp8TO' | 'DYZ9a0_Yf';
  /**
   * To
   * Range: min: 0, step: 0.1
   * @default 500
   */
  JwI1GptEt?: number;
  /**
   * Surfix
   * @default "+"
   */
  saSQNu_F6?: string;
  /**
   * Title
   * @default "Lawns Maintained"
   */
  jPHNKQZin?: string;
  /** Additional properties */
  [key: string]: unknown;
}
