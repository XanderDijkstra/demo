# Phone Number

Exported from Framer using Design to AI.

## Components

- `Phone`
- `Phone2`
- `Counter`
- `Counter2`
- `Counter3`
- `Counter4`
- `I1fnwp21f`
- `I1fnwp21f2`
- `I1fnwp21f3`
- `I1fnwp21f4`
- `DemoButton2`
- `Button`
- `ChooseCard`
- `ChooseCard2`
- `ChooseCard3`
- `TextBox`
- `TextBox2`
- `Button2`
- `ServiceCard`
- `ServiceCard2`
- `ServiceCard3`
- `ServiceCard4`
- `ServiceCard5`
- `ServiceCard6`
- `Button3`
- `Counter5`
- `Counter6`
- `Counter7`
- `Counter8`
- `TextIcon`
- `TextIcon2`
- `Button4`
- `WorkCard`
- `WorkCard2`
- `WorkCard3`
- `WorkCard4`
- `Slideshow`
- `Button5`
- `Button6`
- `Faq`
- `BlogCardV1`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion
```

## Usage

```tsx
import { Phone } from './Phone Number';

function App() {
  return <Phone />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Phone Number/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Phone Number/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <Phone variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Phone Number/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={Phone}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
