export interface PhoneProps {
  /**
   * Variant
   * Options: "q7YdKoN2D" | "KJHdtRU4Q" | "ZqgGmmkod"
   */
  variant?: 'q7YdKoN2D' | 'KJHdtRU4Q' | 'ZqgGmmkod';
  /**
   * Number
   * @default "(959) 555-0123"
   */
  dRQBVZYra?: string;
  ondRQBVZYraChange?: string;
  /**
   * Link
   */
  d2kBHCORZ?: string;
  onpDUqoJUnRChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
