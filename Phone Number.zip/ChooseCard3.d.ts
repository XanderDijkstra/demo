export interface Choosecard3Props {
  /**
   * Variant
   * Options: "F53TKDfRI" | "E0_OuOrfV" | "PQpdbQ4kY"
   */
  variant?: 'F53TKDfRI' | 'E0_OuOrfV' | 'PQpdbQ4kY';
  /**
   * Icon
   * @default {"identifier":"local-module:vector/eSwlrWaki:default","moduleId":"13LRHLT49Gv4dETqRCjh"}
   */
  Lg2nluLL3?: string;
  /**
   * Title
   * @default "Trained Gardeners"
   */
  jnATsjaBC?: string;
  /**
   * Paragraph
   * @default "Relax and enjoy a greener, more beautiful garden—expertly crafted to match your vision."
   */
  EDm3Z_lpm?: string;
  /** Additional properties */
  [key: string]: unknown;
}
