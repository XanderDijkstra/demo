export interface SlideshowProps {
  /**
   * Variant
   * Options: "TLJ3ftvLe" | "sxXwsprn1" | "ZQppCK6Ru" | "oy4VJWJ5w" | "odRWoV2PM" | "MOJprjvjx" | "HioHRoyTn" | "DKwtmnVmB" | "NeyD3RZIO"
   */
  variant?: 'TLJ3ftvLe' | 'sxXwsprn1' | 'ZQppCK6Ru' | 'oy4VJWJ5w' | 'odRWoV2PM' | 'MOJprjvjx' | 'HioHRoyTn' | 'DKwtmnVmB' | 'NeyD3RZIO';
  /** Additional properties */
  [key: string]: unknown;
}
