export interface Workcard2Props {
  /**
   * Variant
   * Options: "KyEkVw05U" | "UrOHgiUCU"
   */
  variant?: 'KyEkVw05U' | 'UrOHgiUCU';
  /**
   * Label
   * @default "(001)"
   */
  X9A6xxeSl?: string;
  /**
   * Title
   * @default "Receive a Quote"
   */
  gYQxvbUC7?: string;
  /**
   * Paragraph
   * @default "We provide a detailed estimate based on our inspection findings."
   */
  Z8B2TOkEC?: string;
  /**
   * Image
   */
  oFv8m8qum?: string;
  /** Additional properties */
  [key: string]: unknown;
}
