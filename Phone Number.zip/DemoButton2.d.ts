export interface Demobutton2Props {
  /**
   * Variant
   * Options: "lfTyWqvl1" | "Dr5IwaPOp" | "TMoipGaGf" | "fk9ZVugw5" | "XUtTX9HK2"
   */
  variant?: 'lfTyWqvl1' | 'Dr5IwaPOp' | 'TMoipGaGf' | 'fk9ZVugw5' | 'XUtTX9HK2';
  /** Additional properties */
  [key: string]: unknown;
}
