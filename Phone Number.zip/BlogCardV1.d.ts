export interface Blogcardv1Props {
  /**
   * Variant
   * Options: "omP1ArXQ8" | "yH_WEwULe"
   */
  variant?: 'omP1ArXQ8' | 'yH_WEwULe';
  /**
   * Image
   */
  mx8L3SAx1?: string;
  /**
   * Date
   * @default "Dec 1, 2025"
   */
  Ig_aHHTzc?: string;
  /**
   * Title
   * @default "Transform Your Outdoors with Expert Advice"
   */
  BZ02a0WAQ?: string;
  /** Additional properties */
  [key: string]: unknown;
}
