export interface TexticonProps {
  /**
   * Icon
   * @default {"identifier":"module:w40SZiic6YMqhTAYTsBI/8cmhwPjbK9EV5nLbGszK/cyrZJj1mu.js:default","moduleId":"w40SZiic6YMqhTAYTsBI"}
   */
  jkwrN4bFr?: string;
  /**
   * Title
   * @default "Free garden inspection consultation"
   */
  e1piwAQLS?: string;
  /** Additional properties */
  [key: string]: unknown;
}
