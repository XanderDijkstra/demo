export interface TextboxProps {
  /**
   * Title
   * @default "Quality You Can Trust"
   */
  iYnGA5nqj?: string;
  /**
   * Text
   * @default "Reliable service clear communication consistent results."
   */
  fLWp6awn9?: string;
  /** Additional properties */
  [key: string]: unknown;
}
