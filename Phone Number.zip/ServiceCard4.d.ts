export interface Servicecard4Props {
  /**
   * Variant
   * Options: "jsaDXocGJ" | "TDa48uCn9" | "geU6qTRSM" | "dRcQeuk_N"
   */
  variant?: 'jsaDXocGJ' | 'TDa48uCn9' | 'geU6qTRSM' | 'dRcQeuk_N';
  /**
   * Image
   */
  F4BIUe4Pj?: string;
  /**
   * Title
   * @default "Shrub Trimming"
   */
  nWQGKxgbx?: string;
  onnWQGKxgbxChange?: string;
  /**
   * Paragraph
   * @default "With our full-service care you can keep garden lush lively and exquisitely arranged."
   */
  hG9rpoGWd?: string;
  onhG9rpoGWdChange?: string;
  /**
   * Link
   */
  rlbXy08qZ?: string;
  /** Additional properties */
  [key: string]: unknown;
}
