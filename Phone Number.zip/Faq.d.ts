export interface FaqProps {
  /**
   * Variant
   * Options: "bfEj_LSlf" | "A0Wzo8KfY" | "lNZnMF21N" | "M8Jsj0I9c" | "JpRBTuMv_"
   */
  variant?: 'bfEj_LSlf' | 'A0Wzo8KfY' | 'lNZnMF21N' | 'M8Jsj0I9c' | 'JpRBTuMv_';
  /** Additional properties */
  [key: string]: unknown;
}
