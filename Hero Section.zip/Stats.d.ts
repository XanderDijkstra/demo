export interface StatsProps {
  /**
   * Variant
   * Options: "b64B5bfwi" | "VNvtjuctp" | "VhR1nC7ED"
   */
  variant?: 'b64B5bfwi' | 'VNvtjuctp' | 'VhR1nC7ED';
  /** Additional properties */
  [key: string]: unknown;
}
