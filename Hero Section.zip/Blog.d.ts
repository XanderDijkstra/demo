export interface BlogProps {
  /**
   * Variant
   * Options: "Umqxf9j2X" | "xKyuEZda1" | "N4kEcO0q5"
   */
  variant?: 'Umqxf9j2X' | 'xKyuEZda1' | 'N4kEcO0q5';
  /** Additional properties */
  [key: string]: unknown;
}
