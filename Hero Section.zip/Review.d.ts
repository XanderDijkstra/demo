export interface ReviewProps {
  /**
   * Variant
   * Options: "yj1roa9nj" | "ZIjP51lgn" | "NH1rgPr2n"
   */
  variant?: 'yj1roa9nj' | 'ZIjP51lgn' | 'NH1rgPr2n';
  /** Additional properties */
  [key: string]: unknown;
}
