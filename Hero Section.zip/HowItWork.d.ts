export interface HowitworkProps {
  /**
   * Variant
   * Options: "IN3k5i1VJ" | "tjRJvXGfs" | "DZvwzY6Z5"
   */
  variant?: 'IN3k5i1VJ' | 'tjRJvXGfs' | 'DZvwzY6Z5';
  /** Additional properties */
  [key: string]: unknown;
}
