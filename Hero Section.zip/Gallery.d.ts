export interface GalleryProps {
  /**
   * Variant
   * Options: "OGkuJwpqq" | "Et2lwO06o" | "ggitDlngd"
   */
  variant?: 'OGkuJwpqq' | 'Et2lwO06o' | 'ggitDlngd';
  /** Additional properties */
  [key: string]: unknown;
}
