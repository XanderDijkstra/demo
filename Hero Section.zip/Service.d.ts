export interface ServiceProps {
  /**
   * Variant
   * Options: "lk_8NvRIs" | "Omv2emDwo" | "uGZ3BMCEy"
   */
  variant?: 'lk_8NvRIs' | 'Omv2emDwo' | 'uGZ3BMCEy';
  /** Additional properties */
  [key: string]: unknown;
}
