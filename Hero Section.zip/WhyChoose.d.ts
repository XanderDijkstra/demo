export interface WhychooseProps {
  /**
   * Variant
   * Options: "mSjgD8pWD" | "YtzUMC5oa" | "I9gmGEPOT"
   */
  variant?: 'mSjgD8pWD' | 'YtzUMC5oa' | 'I9gmGEPOT';
  /** Additional properties */
  [key: string]: unknown;
}
