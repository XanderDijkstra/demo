export interface HeroProps {
  /**
   * Variant
   * Options: "LV87zzXaA" | "EYN0s8m_3" | "zf6fgjHIZ"
   */
  variant?: 'LV87zzXaA' | 'EYN0s8m_3' | 'zf6fgjHIZ';
  /** Additional properties */
  [key: string]: unknown;
}
