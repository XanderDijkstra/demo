export interface FaqProps {
  /**
   * Variant
   * Options: "awrgypdto" | "FsYTuPPCq" | "k86CvSwA1"
   */
  variant?: 'awrgypdto' | 'FsYTuPPCq' | 'k86CvSwA1';
  /** Additional properties */
  [key: string]: unknown;
}
