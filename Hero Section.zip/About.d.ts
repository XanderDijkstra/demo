export interface AboutProps {
  /**
   * Variant
   * Options: "rVEFYaO2Z" | "NrpFbqg3r" | "jmhnJmVun"
   */
  variant?: 'rVEFYaO2Z' | 'NrpFbqg3r' | 'jmhnJmVun';
  /** Additional properties */
  [key: string]: unknown;
}
