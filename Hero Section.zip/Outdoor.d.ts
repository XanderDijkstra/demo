export interface OutdoorProps {
  /**
   * Variant
   * Options: "EbrnYbH8A" | "hxvAbGpJd" | "OX5dFEqa1"
   */
  variant?: 'EbrnYbH8A' | 'hxvAbGpJd' | 'OX5dFEqa1';
  /** Additional properties */
  [key: string]: unknown;
}
